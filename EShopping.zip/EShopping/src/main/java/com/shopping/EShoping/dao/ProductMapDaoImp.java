package com.shopping.EShoping.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Component;


import com.shopping.EShopping.model.Product;
import com.shopping.EShopping.data.ProductMap;

@Repository

public class ProductMapDaoImp implements ProductDao{

	public ProductMapDaoImp() {
		System.out.println("ProductMapDaoImp default constructor created");
		
		
	}

	@Override
	public Product findProduct(int prodID) {
		// TODO Auto-generated method stub
		return ProductMap.INSTANCE.getMap().get(prodID);
	}

	@Override
	public boolean deleteProduct(int prodID) {
		// TODO Auto-generated method stub
		
		if (ProductMap.INSTANCE.getMap().containsKey(prodID)) {
			ProductMap.INSTANCE.getMap().remove(prodID);
			return true;
		}
		return false;
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		
		if(ProductMap.INSTANCE.getMap().containsKey(product.getProdID())) {
			ProductMap.INSTANCE.getMap().put(product.getProdID(), product);
			return true;
		}
		return false;
	}

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		return ProductMap.INSTANCE.getMap().put(product.getProdID(), product) == product;
	}

	@Override
	public List<Product> findAllProducts() {
		// TODO Auto-generated method stub
		return new ArrayList<>(ProductMap.INSTANCE.getMap().values());
	}
}











