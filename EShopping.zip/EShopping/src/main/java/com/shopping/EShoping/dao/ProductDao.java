package com.shopping.EShoping.dao;

import com.shopping.EShopping.model.Product;
import java.util.List;

public interface ProductDao {
	
	Product findProduct(int prodID);
	
	boolean deleteProduct(int prodID);
	
	boolean updateProduct(Product product);
	
	boolean addProduct(Product product);
	
	List<Product> findAllProducts();
	

}
