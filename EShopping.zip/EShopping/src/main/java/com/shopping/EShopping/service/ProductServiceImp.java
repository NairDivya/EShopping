package com.shopping.EShopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.EShopping.model.*;
import com.shopping.EShopping.repository.ProductJPARepository;

@Service("psi")
public class ProductServiceImp implements ProductService{
	
	@Autowired
	private ProductJPARepository repository;
	
	public ProductServiceImp() {
		System.out.println("Product Service Imp created");
		
	}
	
	@Override
	public Product findProduct(int prodID) {
		return repository.findById(prodID).get();
		
	}

	@Override
	public boolean deleteProduct(int prodID) {
		// TODO Auto-generated method stub
		Product p = repository.findById(prodID).get();
		
		if(p != null) {
			repository.delete(p);
			return true;
		}
		return false;
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		Product p = repository.findById(product.getProdID()).get();
		
		if(p !=null) {
			repository.save(product);
			return true;
		}
		return false;
	}

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		
		return repository.save(product) == product;
	}

	@Override
	public List<Product> findAllProducts() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}
	
	

}
