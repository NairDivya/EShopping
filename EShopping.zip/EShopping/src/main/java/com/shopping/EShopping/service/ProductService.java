package com.shopping.EShopping.service;

import com.shopping.EShopping.model.*;

import java.util.List;

public interface ProductService {
	
	Product findProduct(int prodID);
	
	boolean deleteProduct(int prodID);
	
	boolean updateProduct(Product product);
	
	boolean addProduct(Product product);
	
	List<Product> findAllProducts();
	

}
