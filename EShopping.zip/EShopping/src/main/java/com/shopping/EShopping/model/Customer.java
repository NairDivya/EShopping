package com.shopping.EShopping.model;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component



public class Customer {
	
	@Autowired
	private Product prodName;
	private Product prodPrice;

	public Customer() {
		super();
		System.out.println("Customer Details");
		this.custID = new Random().nextInt(1000);
	}
	
	
	private int custID;
	private String custName;
	private String custAddr;
	public Customer(String custName, int custID, String custAddr) {
		this.custName = custName;
		this.custID = new Random().nextInt(1000);
		this.custAddr = custAddr;
		System.out.println("Customer Name: " + custName);
		System.out.println("Customer ID: " + custID);
		System.out.println("Customer Address: " + custAddr);
		
	}
	
	
	public int getCustID() {
		return custID;
	}
	
	public void setCustId(int custID) {
		this.custID= custID;
	}
	
	public String getCustName() {
		return custName;
	}
	
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	
	public String getCustAddr() {
		return custAddr;
	}
	
	public void setCustAddr(String custAddr) {
		this.custAddr = custAddr;
	}
	
	public Product prodName() {
		return prodName;
	}
	
	public Product prodPrice() {
		return prodPrice;
	
	}
	@Override
	public String toString() {
		return "ECustomer [custID=" + custID + ", custName=" + custName 
				+ ", custAddr=" + custAddr + "]";
	}


}
