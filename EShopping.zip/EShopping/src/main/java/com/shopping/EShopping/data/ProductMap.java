package com.shopping.EShopping.data;

import java.util.HashMap;
import java.util.Map;

import com.shopping.EShopping.model.Product;

public enum ProductMap {
 INSTANCE;
	
	private Map<Integer, Product> map;
	
	private ProductMap() {
		map = new HashMap<>();
		
		Product p1 = new Product("Book", "100");
		Product p2 = new Product("Pen", "20");
		Product p3 = new Product("Shampoo", "300");
		Product p4 = new Product("Facewash", "150");
		
		map.put(p1.getProdID(), p1);
		map.put(p2.getProdID(), p2);
		map.put(p3.getProdID(), p3);
		map.put(p4.getProdID(), p4);
		
	}
	
	public Map<Integer, Product> getMap(){
		return map;
	}


}











