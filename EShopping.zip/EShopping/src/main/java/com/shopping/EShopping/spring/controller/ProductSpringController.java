package com.shopping.EShopping.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.EShopping.model.Product;
import com.shopping.EShopping.service.ProductService;

@Controller
public class ProductSpringController {
	
	@Qualifier("psi")
	@Autowired
	private ProductService productService;
	
	public ProductSpringController() {
		System.out.println("PSContoller created");
		
	}
	
	@RequestMapping(value="/sproducts",method=RequestMethod.GET)
	public ModelAndView getAllProducts() {
		return new ModelAndView("productList", "products", productService.findAllProducts());
	}
	
	@RequestMapping(value="/sproducts/edit/{prodID}", method=RequestMethod.GET)
	public String editProduct(@PathVariable("prodID") int prodID, ModelMap map) {
		System.out.println("In editproduct " +prodID);
		map.addAttribute("products", productService.findProduct(prodID));
		map.addAttribute("products", productService.findAllProducts());
		
		return "editProduct";
	}
	
	@RequestMapping(value="/sproducts/delete", method=RequestMethod.GET)
	public String deleteProduct(@RequestParam("prodID") int prodID, ModelMap map) {
		System.out.println("In deleteproduct " +prodID);
		
		productService.deleteProduct(prodID);
		map.addAttribute("products", productService.findAllProducts());
		return "productList";
	}
	
	@RequestMapping(value="/sproducts/new",method=RequestMethod.GET)
	public String newProduct(ModelMap map) {
		map.addAttribute("product", new Product());
		map.addAttribute("products", productService.findAllProducts());
		
		return "addProduct";
	}
	
	@RequestMapping(value="/sproducts/add",method=RequestMethod.POST)
	public String addProduct(Product product,ModelMap map) {
		productService.addProduct(product);
		map.addAttribute("products", productService.findAllProducts());
		
		return "productList";
	}
	
	@RequestMapping(value="/sproducts/update", method=RequestMethod.POST)
	
	public String updateProduct(Product product,ModelMap map) {
		productService.updateProduct(product);
		map.addAttribute("products", productService.findAllProducts());
		
		return "productList";
	}
	

}









