package com.shopping.EShopping.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class Cart {
	
	@Autowired
	private Product prodName;
	private Product prodPrice;
	private Customer custName;
	private Customer custAddr;

	public Cart() {
		super();
		System.out.println("Cart details");
	}
	
	public Product getProdName() {
		return prodName;
	}
	
	public Product getProdPrice() {
		return prodPrice;
	}
	
	public Customer getCustName() {
		return custName;
	}
	
	public Customer getCustAddr() {
		return custAddr;
	}

}
