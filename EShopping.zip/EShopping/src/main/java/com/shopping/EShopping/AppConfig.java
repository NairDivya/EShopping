package com.shopping.EShopping;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = "com.estore.EShopping.model")
@Configuration

public class AppConfig {

}
