package com.shopping.EShopping.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class IndexController {

	@RequestMapping(value={"/"} )
    public String login(Model model) {
        model.addAttribute("message", "Hello Reader !!");
        return "index";
    }
 	     
  @PostMapping("/home")
    public String home(Model model) {	 
	   model.addAttribute("message", "you are in home page !!");
       return "home";
    } 
	

}
