package com.shopping.EShopping.model;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name="Product")
@Scope("prototype")
@Component
public class Product {
	
	@Id // pk
	 @Column(name="prodID")
	private int prodID;
	private String prodName;
	private String prodPrice;

	public Product() {
		super();
		System.out.println("Displaying Products");
		this.prodID = new Random().nextInt(1000);
	}
	
	
	
	public Product(String prodName,  String prodPrice ) {
		this.prodName = prodName;
		this.prodID = new Random().nextInt(1000);
		this.prodPrice = prodPrice;
		System.out.println("Product Name: " + prodName);
		System.out.println("Product ID: " + prodID);
		System.out.println("Product Price: " + prodPrice);
		
	}
	
	public String getProdName() {
		return prodName;
	}
	
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	
	public String getProdPrice() {
		return prodPrice;
	}
	
	public void setProdPrice(String prodPrice) {
		this.prodPrice = prodPrice;
	}
	 
	public int getProdID() {
		return prodID;
	}
	
	public void setProdID(int prodID) {
		this.prodID = prodID;
	}
	
	@Override
	public String toString() {
		return "Product[prodID=" + prodID + ", prodName=" + prodName 
				+ ", prodPrice=" + prodPrice +"]";
	}


}
